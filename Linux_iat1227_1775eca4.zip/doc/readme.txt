开发指南文档请参考:http://doc.xfyun.cn/msc_windows
API接口文档请参考:http://mscdoc.xfyun.cn/windows/api
